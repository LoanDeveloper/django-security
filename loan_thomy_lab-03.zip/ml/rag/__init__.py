"""
Module RAG (Retrieval-Augmented Generation) pour l'assistant
"""
