"""
Module de prétraitement des données
"""
