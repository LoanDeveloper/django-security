"""
Module de calcul de similarité et ranking
"""
