"""
Module ML pour SmartMarket
Recommandations, recherche sémantique et assistant RAG
"""
