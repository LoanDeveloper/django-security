"""
Module de vectorisation (TF-IDF et embeddings)
"""
